import 'package:expense_tracker_fiap/repository/categoria_repository.dart';
import 'package:flutter/material.dart';

class CategoriasPage extends StatefulWidget {
  const CategoriasPage();

  @override
  State<CategoriasPage> createState() => _CategoriasPageState();
}

class _CategoriasPageState extends State<CategoriasPage> {
  final categorias = CategoriaRepository().obterCategorias();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Categoria')),
      body: ListView.builder(itemCount: categorias.length, itemBuilder: (buildContext, index){
        return ListTile(
          leading: Icon(categorias[index].icone),
iconColor: categorias[index].cor,
title: Text(categorias[index].nome),
trailing: Text(categorias[index].tipoTransacao.name,style: TextStyle(color: categorias[index].tipoTransacao.name.startsWith('d') ? Colors.red : Colors.green),),
        );

      },
    ));
  }
}
