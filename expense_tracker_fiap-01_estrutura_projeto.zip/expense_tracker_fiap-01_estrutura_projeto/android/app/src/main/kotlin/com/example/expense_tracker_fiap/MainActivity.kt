package com.example.expense_tracker_fiap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
