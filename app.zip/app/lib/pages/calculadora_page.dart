import 'package:app/constants.dart';
import 'package:flutter/material.dart';

import '../components.dart';

class Calculadora_page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Calcular IMC'), centerTitle: true),
      body: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Calculadora_widget(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.male,
                          size: 80.0,
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Masculino',
                          style: kLabelTextStyle,
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Calculadora_widget(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.female,
                          size: 80.0,
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Feminino',
                          style: kLabelTextStyle,
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
              child: Calculadora_widget(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(
                'Height',
                style: kLabelTextStyle,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '1.83',
                    style: kNumberTextStyle,
                  ),
                  Text('cm')
                ],
              ),
              Slider(value: 0, onChanged: (double value) {})
            ]),
          )),
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Calculadora_widget(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [],
                    ),
                  ),
                ),
                Expanded(
                  child: Calculadora_widget(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [],
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
