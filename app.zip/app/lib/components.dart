import 'package:flutter/material.dart';

import 'constants.dart';

class Calculadora_widget extends StatelessWidget {
  final Widget child;
  const Calculadora_widget({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15.0),
      decoration: BoxDecoration(
        color: kActiveCardColour,
        borderRadius: BorderRadius.circular(10),
      ),
      child: child,
    );
  }
}
