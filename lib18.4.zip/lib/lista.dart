import 'package:flutter/material.dart';

class Lista extends StatefulWidget {
  const Lista({Key? key}) : super(key: key);

  @override
  State<Lista> createState() => _Lista();
}

class _Lista extends State<Lista> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
          ListTile(
            title: Text('a'),
            subtitle: Text('a'),
          ),
          ListTile(
            title: Text('b'),
            subtitle: Text('b'),
          ),
        ],
      ),
    );
  }
}
